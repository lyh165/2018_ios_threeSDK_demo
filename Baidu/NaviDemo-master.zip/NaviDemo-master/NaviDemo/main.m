//
//  main.m
//  NaviDemo
//
//  Created by wzh on 2017/8/15.
//  Copyright © 2017年 WZH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
