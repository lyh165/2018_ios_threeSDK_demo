// 项目初始化的单例

#import <Foundation/Foundation.h>

@interface AppProjectName : NSObject
+ (AppProjectName *)getInstance;
@end
