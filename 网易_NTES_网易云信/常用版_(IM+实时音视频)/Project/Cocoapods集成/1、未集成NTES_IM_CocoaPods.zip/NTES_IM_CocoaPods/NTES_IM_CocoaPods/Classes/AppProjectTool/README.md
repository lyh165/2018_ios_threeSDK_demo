# AppProjectTool (项目工具)
    1、用于初始化项目、初始化第三方的SDK
    

## AppDelegate_Sign(应用代理的单例)
    1、初始化 自己的设置、H5+框架的初始化

## AppDelegate_Sign_ThreeLib(应用代理的单例_第三方SDK)
    1、初始化 第三方的SDK




















## AppDelegate_Category(应用代理的分类)__ 暂时未使用

## AppDelegate_Category_ThreeLib(应用代理的第三方分类)__ 暂时未使用
