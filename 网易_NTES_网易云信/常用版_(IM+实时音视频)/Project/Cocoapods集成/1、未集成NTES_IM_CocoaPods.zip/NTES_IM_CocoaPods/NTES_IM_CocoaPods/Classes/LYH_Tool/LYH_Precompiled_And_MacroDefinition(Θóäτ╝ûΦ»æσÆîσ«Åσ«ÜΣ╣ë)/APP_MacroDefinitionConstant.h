//
//  APP_MacroDefinitionConstant.h
//  NTES_IM_CocoaPods
//
//  Created by lee on 2018/11/1.
//  Copyright © 2018年 lee. All rights reserved.
//

#ifndef APP_MacroDefinitionConstant_h
#define APP_MacroDefinitionConstant_h

#pragma mark ------------------------ h5+文件加载路径 ------------------------

#define K_H5App_BaseInit_Location_pWWWPath @"Pandora/apps/H55E48D08/www"    // www的路径
#define K_H5App_BaseInit_Location_IndexPath @"form_mobile/index/foot.html"    // launch_path的路径

#endif /* APP_MacroDefinitionConstant_h */
